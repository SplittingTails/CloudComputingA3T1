function spinner() {
    document.getElementsByClassName("spinner-border")[0].style.display = "none";
}