<?php include ("header.php");?>
<h1>Page not found</h1>
<a href="/">Go back to home</a>
<?php include ("footer.php");?>
