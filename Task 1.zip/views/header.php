<?php 
session_start();
 ?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bootstrap demo</title>

  <link href="vendor\twbs\bootstrap\dist\css\bootstrap.min.css" rel="stylesheet">
</head>
<header>
  <?php require ('views/Nav.php') ?>
</header>

<body>
  <div class="container">